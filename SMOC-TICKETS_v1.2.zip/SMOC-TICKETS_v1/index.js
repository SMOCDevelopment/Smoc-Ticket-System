require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, Collection, GatewayIntentBits } = require('discord.js');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

client.commands = new Collection();

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    client.commands.set(command.data.name, command);
    commands.push(command.data.toJSON());
}

const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = process.env.GUILD_ID;
const TOKEN = process.env.DISCORD_TOKEN;

const rest = new REST({ version: '10' }).setToken(TOKEN);

(async () => {
    try {
        console.log('Started refreshing application (/) commands.');

        await rest.put(
            Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
            { body: commands },
        );

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
})();

client.on('interactionCreate', async interaction => {
    // First, run your external handler
    const handler = require('./events/interactionCreate.js'); 
    try {
        await handler.execute(interaction);
    } catch (error) {
        console.error('Interaction handler error:', error);
    }

    // Then handle slash commands
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(error);
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp({ content: 'There was an error while executing this command!', ephemeral: true });
        } else {
            await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
        }
    }
});

client.once('ready', () => {
    console.log(`
  ____  __  __  ___   ____   ____                 _                                  _   
 / ___||  \\/  |/ _ \\ / ___| |  _ \\  _____   _____| | ___  _ __  _ __ ___   ___ _ __ | |_ 
 \\___ \\| |\\/| | | | | |     | | | |/ _ \\ \\ / / _ \\ |/ _ \\| '_ \\| '_ \` _ \\ / _ \\ '_ \\| __|
  ___) | |  | | |_| | |___  | |_| |  __/\\ V /  __/ | (_) | |_) | | | | | |  __/ | | | |_ 
 |____/|_|  |_|\\___/ \\____| |____/ \\___| \\_/ \\___|_|\\___/| .__/|_| |_| |_|\\___|_| |_|\\__| 
                                                         |_|                                  
                         SMOC - Discord Bot Startup

  Support: https://discord.gg/4vNTtRKt95
  Version: v1.0
    `);

    console.log(`Logged in as ${client.user.tag}!`);
});

client.login(TOKEN);

const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    AttachmentBuilder,
} = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;

        const { customId, channel, guild, user } = interaction;

        // Handle initial close button press: ask for confirmation
        if (customId === 'close_ticket') {
            const confirmRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('confirm_close_yes')
                    .setLabel('✅ Confirm Close')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('cancel_close')
                    .setLabel('❌ Cancel')
                    .setStyle(ButtonStyle.Secondary)
            );

            await interaction.reply({
                content: 'Are you sure you want to close this ticket?',
                components: [confirmRow],
                ephemeral: true,
            });
            return;
        }

        // Cancel close
        if (customId === 'cancel_close') {
            await interaction.update({
                content: '❎ Ticket close canceled.',
                components: [],
            });
            return;
        }

        // Confirm close: save transcript, notify, log, delete channel
        if (customId === 'confirm_close_yes') {
            await interaction.update({
                content: 'Fetching all messages and closing ticket...',
                components: [],
            });

            // Fetch last 100 messages in channel
            const messages = await channel.messages.fetch({ limit: 100 });
            const sortedMessages = [...messages.values()].reverse();

            // Format transcript text
            const transcriptText = sortedMessages
                .map(
                    (m) =>
                        `[${m.createdAt.toISOString()}] ${m.author.tag}: ${m.content || (m.attachments.size > 0 ? '[Attachment]' : '')
                        }`
                )
                .join('\n');

            // Save transcript file
            const fileName = `transcript-${channel.name}.txt`;
            const filePath = path.join(__dirname, '..', 'transcripts', fileName);
            fs.mkdirSync(path.dirname(filePath), { recursive: true });
            fs.writeFileSync(filePath, transcriptText);

            const transcriptAttachment = new AttachmentBuilder(filePath);

            // Extract ticket user ID from channel topic (assuming format set earlier)
            const topic = channel.topic || '';
            const userIdMatch = topic.match(/UserID[: ]+(\d+)/i);
            const ticketUserId = userIdMatch ? userIdMatch[1] : null;

            // DM ticket user
            if (ticketUserId) {
                try {
                    const ticketUser = await guild.members.fetch(ticketUserId);
                    const dmEmbed = new EmbedBuilder()
                        .setTitle('Your ticket has been closed')
                        .setDescription(
                            `Your ticket \`${channel.name}\` has been closed by <@${user.id}>. Thank you for contacting support!`
                        )
                        .addFields(
                            { name: 'Closed By', value: `<@${user.id}>`, inline: true },
                            { name: 'Ticket ID', value: channel.name, inline: true }
                        )
                        .setTimestamp()
                        .setColor(0x00ff99);

                    await ticketUser.send({ embeds: [dmEmbed], files: [transcriptAttachment] });
                } catch {
                    // User DMs might be closed, ignore silently
                }
            }

            // DM support role (fetch role members and DM them)
            try {
                const supportRole = guild.roles.cache.get(supportRoleID);
                if (supportRole) {
                    const supportEmbed = new EmbedBuilder()
                        .setTitle('Ticket Closed')
                        .setDescription(
                            `Ticket \`${channel.name}\` was closed by <@${user.id}>. Please log this ticket accordingly.`
                        )
                        .addFields(
                            { name: 'Closed By', value: `<@${user.id}>`, inline: true },
                            { name: 'Ticket Channel', value: `<#${channel.id}>`, inline: true }
                        )
                        .setTimestamp()
                        .setColor(0xff5555);
                }
            } catch (e) {
                console.error('Error sending DM to support role:', e);
            }
            // Delete channel after 5 seconds
            setTimeout(async () => {
                try {
                    await channel.delete();
                } catch (err) {
                    console.error('Failed to delete ticket channel:', err);
                }
            }, 5000);
        }
    },
};

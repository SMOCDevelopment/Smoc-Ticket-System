// Create a channel in your discord server and do /embedhelp and it will post a guide for the users on how to create tickets.
// this does not have permissions to use this command. If it becomes a problem, I will add a permission to it. Do /rate and let me know in the feedback.
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embedhelp')
    .setDescription('Guide Users on how to create tickets'),
  
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x0099FF)
      .setTitle('Hello! This is [examples name] support ticket system!')
      .setAuthor({ name: 'Created by SMOC DEVELOPMENT' })
      .setDescription('Our ticket system is designed to help you with any issues you may have. Please select the appropriate ticket type for your needs.')
      .setThumbnail('https://images.discordapp.net/avatars/811873192230518784/4fd696b7dc9680a5824ce4ec42aec3b6.png?size=512') // Replace with your thumbnail URL, could be a logo or something
      // Its already a ticket logo, so you can use it or replace it with your own
      .addFields(
        { name: 'Need support?', value: '/ticket create support' },
        { name: 'Need to report staff', value: '/ticket create report' },
        { name: 'Need store help?', value: '/ticket create store' },
        { name: 'Need to report a dev issue?', value: '/ticket create developer' },
      )
      .setTimestamp()
      .setFooter({ text: 'Footer text' });

    await interaction.reply({ embeds: [embed] });
  },
};

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Get help with the bot'),

    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('Help & Setup Guide')
            .setDescription('Here are some commands and setup instructions for the bot:')
            .addFields(
                {
                    name: 'Setup Guide',
                    value: 
`• Role Permissions, Logging Channel, and Category configurations are set at the TOP of the command files (usually within the first 30 lines).
• To customize, open the relevant command file (e.g., \`/commands/store.js\`).

**Example: Change Staff Role ID**

1. Open \`/commands/store.js\`
2. Look near the top for the line like:
\`\`\`
const supportRoleID = '1368648318204383272'; // Store Help role ID
\`\`\`
3. Replace the ID string with your server’s staff role ID.

Similarly, you can find and edit:
- \`supportCategoryID\` for the ticket category
- \`logChannelID\` for the logging channel

All important config IDs are declared in the first 30 lines of the files.

• After editing, save and restart the bot for changes to take effect.

Use commands like \`/create_ticket_store\` to create tickets.

For more help, contact the developer.`
                },
                { name: '/embedhelp', value: 'Simple guide to help users on creating tickets. Customize it in the files.' },
                { name: '/rate', value: 'Rate your experience with the bot' },
            )
            .setTimestamp()
            .setFooter({ text: 'Created By SMOC DEVELOPMENT / Koldin' });

        await interaction.reply({ embeds: [embed] });
    },
};

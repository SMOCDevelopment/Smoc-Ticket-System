const {
    SlashCommandBuilder,
    EmbedBuilder,
    PermissionFlagsBits,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
} = require('discord.js');

const supportRoleID = ''; // Support role ID
const supportCategoryID = ''; // Support category ID
const logChannelID = ''; // Log channel ID

module.exports = {
    data: new SlashCommandBuilder()
        .setName('create_ticket_support')
        .setDescription('Create a support ticket for a user.')
        .addStringOption(option =>
            option
                .setName('reason')
                .setDescription('Detailed reason for the ticket')
                .setRequired(true)
        ),

    async execute(interaction) {
        const guild = interaction.guild;
        const targetUser = interaction.user;
        const reason = interaction.options.getString('reason');

        const ticketNumber = Math.floor(6000 + Math.random() * 9000);
        const channelName = `support-${ticketNumber}`;

        const existing = guild.channels.cache.find(ch =>
            ch.name.startsWith('support-') &&
            ch.permissionOverwrites.cache.has(targetUser.id) &&
            ch.permissionsFor(targetUser.id).has(PermissionFlagsBits.ViewChannel)
        );

        if (existing) {
            return interaction.reply({
                content: `❌ You already have an open ticket: <#${existing.id}>`,
                ephemeral: true,
            });
        }

        const channel = await guild.channels.create({
            name: channelName,
            type: 0, 
            parent: supportCategoryID,
            permissionOverwrites: [
                { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                {
                    id: targetUser.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
                {
                    id: supportRoleID,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
            ],
        });

        await channel.setTopic(`Support Ticket | UserID: ${targetUser.id} | ID: ${ticketNumber}`);


        const logChannel = guild.channels.cache.get(logChannelID);
        if (logChannel && logChannel.isTextBased()) {
            const logEmbed = new EmbedBuilder()
                .setTitle('🎟️ Tickets')
                .addFields(
                    { name: 'Created By', value: `<@${targetUser.id}>` },
                    { name: 'Section', value: `Support` },
                    { name: 'Reason', value: reason },
                    { name: 'Ticket ID', value: `${ticketNumber}` }
                )
                .setTimestamp()
                .setColor(0x00ff99);

            await logChannel.send({ embeds: [logEmbed] });
        }


        const ticketEmbed = new EmbedBuilder()
            .setTitle(`Support Ticket #${ticketNumber}`)
            .setDescription(`Hello <@${targetUser.id}>, a support staff member will assist you shortly.\n\n**Reason:** ${reason}`)
            .setColor(0x00ff99)
            .setTimestamp();

        const closeButton = new ButtonBuilder()
            .setCustomId('close_ticket')
            .setLabel('Close Ticket')
            .setStyle(ButtonStyle.Danger);

        const row = new ActionRowBuilder().addComponents(closeButton);

        await channel.send({
            content: `<@${targetUser.id}> <@&${supportRoleID}>`,
            embeds: [ticketEmbed],
            components: [row],
        });

        await interaction.reply({
            content: `✅ Ticket created: <#${channel.id}>`,
            ephemeral: true,
        });
    },
};

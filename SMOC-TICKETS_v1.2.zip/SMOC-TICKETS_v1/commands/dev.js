const {
    SlashCommandBuilder,
    EmbedBuilder,
    PermissionFlagsBits,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType,
    ComponentType,
} = require('discord.js');

const supportRoleID = ''; // developer role ID
const supportCategoryID = ''; // Dev category ID
const logChannelID = ''; // Log channel ID

// Error database for common issues
// This is a simple array of objects. Each object contains keywords and a response.
const errorDatabase = [
    {
        keywords: ['connect', 'connection', 'connecting', 'connected'],
        response: '🔧 **Connection Issue:** Please ensure your FiveM is up to date and your firewall isn’t blocking connections.'
    },
    {
        keywords: ['crash', 'crashed', 'crashing', 'crashes'],
        response: '💥 **Crash Issue:** Try clearing your FiveM cache. It often resolves random crash errors.'
    },
    {
        keywords: ['auth', 'authentication', 'login'],
        response: '🔑 **Authentication Issue:** This usually means Steam or Rockstar isn’t properly running. Try restarting both apps and your PC.'
    }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('create_ticket_developer')
        .setDescription('Create a developer help ticket.'),

    async execute(interaction) {
        const guild = interaction.guild;
        const user = interaction.user;
        const ticketUserId = interaction.options.getString('user') || user.id; // Get the user ID from the command or use the command user

        const ticketNumber = Math.floor(1000 + Math.random() * 9000);
        const channelName = `dev-help-${ticketNumber}`;

        const existing = guild.channels.cache.find(ch =>
            ch.name.startsWith('dev-help-') &&
            ch.permissionOverwrites.cache.has(user.id) &&
            ch.permissionsFor(user.id).has(PermissionFlagsBits.ViewChannel)
        );
        if (existing) {
            return interaction.reply({
                content: `❌ You already have an open developer ticket: <#${existing.id}>`,
                ephemeral: true,
            });
        }

        const channel = await guild.channels.create({
            name: channelName,
            type: ChannelType.GuildText,
            parent: supportCategoryID,
            permissionOverwrites: [
                { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                {
                    id: user.id,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
                },
                {
                    id: supportRoleID,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
                },
            ],
        });

        await channel.setTopic(`Dev Help | UserID: ${user.id} | Ticket ID: ${ticketNumber}`);

        const logChannel = guild.channels.cache.get(logChannelID);
        if (logChannel && logChannel.isTextBased()) {
            const logEmbed = new EmbedBuilder()
                .setTitle('🎟️ Developer Tickets')
                .addFields(
                    { name: 'Created By', value: `<@${user.id}>` },
                    { name: 'Section', value: `Developer Help` },
                    { name: 'Ticket ID', value: `${ticketNumber}` }
                )
                .setTimestamp()
                .setColor(0x0099ff);

            await logChannel.send({ embeds: [logEmbed] });
        }

        const ticketEmbed = new EmbedBuilder()
            .setTitle(`🛠️ Developer Help Ticket #${ticketNumber}`)
            .setDescription(`Hello <@${user.id}>, a developer will assist you shortly.\n\nPlease choose a topic to get started by clicking a button below.`)
            .setColor(0x0099ff)
            .setTimestamp();

        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('game_error')
                .setLabel('🎮 Game Error')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('suggestion')
                .setLabel('💡 Suggestion')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('close_ticket')
                .setLabel('🔒 Close Ticket')
                .setStyle(ButtonStyle.Danger)
        );

        await channel.send({
            content: `<@${user.id}> <@&${supportRoleID}>`,
            embeds: [ticketEmbed],
            components: [buttons],
        });

        await interaction.reply({
            content: `✅ Developer ticket created: <#${channel.id}>`,
            ephemeral: true,
        });

        const collector = channel.createMessageComponentCollector({ componentType: ComponentType.Button, time: 600000 });

        collector.on('collect', async i => {
            if (i.user.id !== user.id) return i.reply({ content: 'This isn’t your ticket.', ephemeral: true });

            const closeButtonRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('close_ticket').setLabel('🔒 Close Ticket').setStyle(ButtonStyle.Danger)
            );

            if (i.customId === 'game_error') {
                const errorEmbed = new EmbedBuilder()
                    .setTitle('🎮 Game Error Selected')
                    .setDescription('I have some saved error codes in my database. Please describe the error you are experiencing in detail.')
                    .setColor('#0099ff')
                    .setTimestamp();

                await i.update({ embeds: [errorEmbed], components: [closeButtonRow] });

                const messageCollector = channel.createMessageCollector({ filter: m => m.author.id === user.id, time: 600000 });

                messageCollector.on('collect', async msg => {
                    const content = msg.content.toLowerCase();

                    // Responds to the user if they mention they are still having issues.
                    const troublePhrases = ["didn't work", "didnt work", "didn't fix", "didnt fix", "did not work", "still broken", "no fix", "not solved"];
                    if (troublePhrases.some(phrase => content.includes(phrase))) {
                        const retryEmbed = new EmbedBuilder()
                            .setTitle('🧠 Still having Issues?')
                            .setDescription(`I'm sorry to hear that, <@${user.id}>. Please provide the error code you are receiving and I will try to assist you.`)
                            .setColor('#f1c40f')
                            .setTimestamp();

                        await channel.send({ embeds: [retryEmbed], components: [closeButtonRow] });
                        return;
                    }

                    const match = errorDatabase.find(entry =>
                        entry.keywords.some(keyword => content.includes(keyword.toLowerCase()))
                    );

                    if (match) {
                        const solutionEmbed = new EmbedBuilder()
                            .setTitle('✅ Possible Solution Found')
                            .setDescription(match.response)
                            .setColor('#4caf50')
                            .setTimestamp();

                        await channel.send({ embeds: [solutionEmbed], components: [closeButtonRow] });
                    } else {
                        const noMatchEmbed = new EmbedBuilder()
                            .setTitle('❌ No Match Found')
                            .setDescription(`I couldn't find a solution to that error. A developer will assist you soon.\nIf you do not receive a response within **4 hours**, please consider opening a regular support ticket.`)
                            .setColor('#e74c3c')
                            .setTimestamp();

                        await channel.send({ embeds: [noMatchEmbed], components: [closeButtonRow] });
                    }
                });
            }

            if (i.customId === 'suggestion') {
                const suggestionEmbed = new EmbedBuilder()
                    .setTitle('💡 Suggestion Mode')
                    .setDescription('Please describe your suggestion. Include any links or images so our team can review it.')
                    .setColor('#0099ff')
                    .setTimestamp();

                await i.update({ embeds: [suggestionEmbed], components: [closeButtonRow] });
            }

        });
    },
};

const {
    SlashCommandBuilder,
    EmbedBuilder,
    PermissionFlagsBits,
    ChannelType,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
} = require('discord.js');

const supportRoleID = ''; // Store Help role ID
const supportCategoryID = ''; // Store Help category ID
const logChannelID = ''; // Log channel ID

module.exports = {
    data: new SlashCommandBuilder()
        .setName('create_ticket_store')
        .setDescription('Create a store help ticket for a user.')
        .addStringOption(option =>
            option
                .setName('reason')
                .setDescription('Detailed reason for the ticket')
                .setRequired(true)
        ),

    async execute(interaction) {
        const guild = interaction.guild;
        const targetUser = interaction.user;
        const reason = interaction.options.getString('reason');
        const logChannel = guild.channels.cache.get(logChannelID);

        const existing = guild.channels.cache.find(ch =>
            ch.name.startsWith('store-help-') &&
            ch.permissionOverwrites.cache.has(targetUser.id) &&
            ch.permissionsFor(targetUser.id).has(PermissionFlagsBits.ViewChannel)
        );

        if (existing) {
            return interaction.reply({
                content: `❌ You already have an open ticket: <#${existing.id}>`,
                ephemeral: true,
            });
        }

        const ticketNumber = Math.floor(6000 + Math.random() * 9000);
        const channelName = `store-help-${ticketNumber}`;

        const channel = await guild.channels.create({
            name: channelName,
            type: ChannelType.GuildText,
            parent: supportCategoryID,
            permissionOverwrites: [
                { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                {
                    id: targetUser.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
                {
                    id: supportRoleID,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
            ],
        });

        await channel.setTopic(`Store Help Ticket | UserID: ${targetUser.id} | ID: ${ticketNumber}`);

        if (logChannel && logChannel.isTextBased()) {
            const logEmbed = new EmbedBuilder()
                .setTitle('🛍️ Tickets')
                .addFields(
                    { name: 'Created By', value: `<@${targetUser.id}>` },
                    { name: 'Section', value: 'Store Help' },
                    { name: 'Reason', value: reason },
                    { name: 'Ticket ID', value: `${ticketNumber}` }
                )
                .setTimestamp()
                .setColor(0xffcc00);

            await logChannel.send({ embeds: [logEmbed] });
        }

        const ticketEmbed = new EmbedBuilder()
            .setTitle(`🛍️ Store Help Ticket #${ticketNumber}`)
            .setDescription(`Hello <@${targetUser.id}>, please follow instructions as prompted. \n\n**Reason:** ${reason}`)
            .setColor(0xffcc00)
            .setTimestamp();

        const closeButton = new ButtonBuilder()
            .setCustomId('close_ticket')
            .setLabel('Close Ticket')
            .setStyle(ButtonStyle.Danger);

        const row = new ActionRowBuilder().addComponents(closeButton);

        await channel.send({
            content: `<@${targetUser.id}> <@&${supportRoleID}>`,
            embeds: [ticketEmbed],
            components: [row],
        });

        await interaction.reply({
            content: `✅ Store help ticket created: <#${channel.id}>`,
            ephemeral: true,
        });

        const requestEmbed = new EmbedBuilder()
            .setTitle('🛍️ Store Support Ticket')
            .setDescription(`Please enter your **Purchase Code**.\n\n> If not available, put \`not available\`.`)
            .setColor(0x00aaff)
            .setTimestamp();

        await channel.send({ embeds: [requestEmbed] });

        const filter = m => m.author.id === targetUser.id;
        const collector = channel.createMessageCollector({ filter, max: 1, time: 120000 });

        collector.on('collect', async msg => {
            const purchaseCode = msg.content;

            const summaryEmbed = new EmbedBuilder()
                .setTitle('📦 Store Help Summary')
                .addFields(
                    { name: 'Reason', value: reason },
                    { name: 'Purchase Code', value: `\`${purchaseCode}\`` }
                )
                .setColor(0x00ff99)
                .setFooter({ text: `Ticket ID: ${ticketNumber}` })
                .setTimestamp();

            await channel.send({ content: `<@${targetUser.id}> Thank you! A store associate member will assist you shortly.`, embeds: [summaryEmbed] });

            if (logChannel && logChannel.isTextBased()) {
                const purchaseLogEmbed = new EmbedBuilder()
                    .setTitle('🛍️ Store Help Ticket Update')
                    .addFields(
                        { name: 'User', value: `${targetUser.tag} (<@${targetUser.id}>)`, inline: true },
                        { name: 'Reason', value: reason },
                        { name: 'Purchase Code', value: `\`${purchaseCode}\`` },
                        { name: 'Ticket Channel', value: `<#${channel.id}>` },
                        { name: 'Ticket ID', value: ticketNumber.toString() }
                    )
                    .setColor(0x00ff99)
                    .setTimestamp();

                await logChannel.send({ embeds: [purchaseLogEmbed] });
            }
        });

        collector.on('end', async collected => {
            if (collected.size === 0) {
                try {
                    const currentChannel = await guild.channels.fetch(channel.id).catch(() => null);
                    if (currentChannel && currentChannel.isTextBased() && currentChannel.permissionsFor(guild.members.me).has(PermissionFlagsBits.SendMessages)) {
                        await currentChannel.send(`<@${targetUser.id}> You didn’t respond in time. You can still provide your purchase code anytime in this channel.`);
                    }
                } catch (error) {
                    console.error('Failed to send timeout message:', error);
                }
            }
        });
    },
};

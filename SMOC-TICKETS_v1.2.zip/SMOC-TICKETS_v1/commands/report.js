const {
    SlashCommandBuilder,
    EmbedBuilder,
    PermissionFlagsBits,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType,
    ComponentType,
} = require('discord.js');

const supportRoleID = ''; // Manager Role ID
const supportCategoryID = ''; // Staff Report category ID
const logChannelID = ''; // Filled Report Log channel ID

module.exports = {
    data: new SlashCommandBuilder()
        .setName('create_ticket_report')
        .setDescription('Create a staff report ticket.')
        .addUserOption(option =>
            option
                .setName('reported_user')
                .setDescription('The user you are reporting.')
                .setRequired(true)
        ),

    async execute(interaction) {
        const guild = interaction.guild;
        const reporter = interaction.user;
        const reportedUser = interaction.options.getUser('reported_user');

        const existing = guild.channels.cache.find(ch =>
            ch.name.startsWith('staff-report-') &&
            ch.permissionOverwrites.cache.has(reporter.id) &&
            ch.permissionsFor(reporter.id).has(PermissionFlagsBits.ViewChannel)
        );

        if (existing) {
            return interaction.reply({
                content: `❌ You already have an open ticket: <#${existing.id}>`,
                ephemeral: true,
            });
        }

        const ticketNumber = Math.floor(1000 + Math.random() * 9000);
        const channelName = `staff-report-${ticketNumber}`;
        const channel = await guild.channels.create({
            name: channelName,
            type: ChannelType.GuildText,
            parent: supportCategoryID,
            permissionOverwrites: [
                { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                {
                    id: reporter.id,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
                {
                    id: reportedUser.id,
                    deny: [PermissionFlagsBits.ViewChannel],
                },
                {
                    id: supportRoleID,
                    allow: [
                        PermissionFlagsBits.ViewChannel,
                        PermissionFlagsBits.SendMessages,
                        PermissionFlagsBits.ReadMessageHistory,
                    ],
                },
            ],
        });

        await channel.setTopic(`Staff Report | Reporter: ${reporter.tag} | Reported: ${reportedUser.tag} | ID: ${ticketNumber}`);

        const welcomeEmbed = new EmbedBuilder()
            .setTitle('👋 Welcome to your report ticket!')
            .setDescription('Please wait while we collect some information about your report.\nUse the button below to close this ticket at any time.')
            .setColor(0x00b0f4);

        const closeRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('close_ticket')
                .setLabel('🔒 Close Ticket')
                .setStyle(ButtonStyle.Danger)
        );

        await channel.send({
            content: `<@${reporter.id}> <@&${supportRoleID}>`,
            embeds: [welcomeEmbed],
            components: [closeRow],
        });

        await interaction.reply({ content: `✅ Ticket created: <#${channel.id}>`, ephemeral: true });

        await channel.send(`<@${reporter.id}> Please describe the situation with as much detail as possible, including any clips, screenshots, or evidence.`);

        const collector = channel.createMessageCollector({
            filter: m => m.author.id === reporter.id,
            max: 1,
            time: 120000,
        });

        collector.on('collect', async (msg) => {
            const content = msg.content;
            const links = [...content.matchAll(/https?:\/\/[^\s]+/gi)].map(m => m[0]);
            const hasAttachments = msg.attachments.size > 0;
            const ruleBreak = detectRuleViolation(content);

            const summaryEmbed = new EmbedBuilder()
                .setTitle('Staff Report Summary')
                .setDescription('Here’s what you submitted:')
                .addFields(
                    { name: 'Your Message', value: content.length > 1024 ? content.slice(0, 1020) + '...' : content },
                    { name: 'Links Found', value: links.length ? links.join('\n') : 'None' },
                    { name: 'Media Attached', value: hasAttachments ? '✅ Yes' : '❌ No' },
                    { name: 'Bot Analysis', value: ruleBreak ? `⚠️ Likely violates rule: **${ruleBreak}**` : '✅ No clear violation detected' }
                )
                .setColor(0xffcc00)
                .setTimestamp();

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('confirm_report').setLabel('Yes').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('add_more').setLabel('No, add more').setStyle(ButtonStyle.Secondary)
            );

            const summaryMsg = await channel.send({
                content: `<@${reporter.id}> Please confirm your report or add more:`,
                embeds: [summaryEmbed],
                components: [row],
            });

            const buttonCollector = summaryMsg.createMessageComponentCollector({
                componentType: ComponentType.Button,
                time: 300000,
                filter: i => i.user.id === reporter.id,
            });

            buttonCollector.on('collect', async i => {
                if (i.customId === 'confirm_report') {
                    await i.update({ content: '✅ Report confirmed and filed for a manager to review. You may close this ticket.', embeds: [], components: [] });

                    const logChannel = guild.channels.cache.get(logChannelID);
                    if (logChannel) {
                        const logEmbed = new EmbedBuilder()
                            .setTitle('📨 New Staff Report Submitted')
                            .addFields(
                                { name: 'Reporter', value: `${reporter.tag} (<@${reporter.id}>)`, inline: true },
                                { name: 'Reported User', value: `${reportedUser.tag} (<@${reportedUser.id}>)`, inline: true },
                                { name: 'Message', value: content.length > 1024 ? content.slice(0, 1020) + '...' : content },
                                { name: 'Links Found', value: links.length ? links.join('\n') : 'None', inline: true },
                                { name: 'Media Attached', value: hasAttachments ? '✅ Yes' : '❌ No', inline: true },
                                { name: 'Bot Analysis', value: ruleBreak ? ruleBreak : 'No clear violation detected', inline: true },
                                { name: 'Ticket Channel', value: channel ? channel.toString() : 'unknown', inline: true },
                                { name: 'Ticket ID', value: `${ticketNumber}`, inline: true },
                                { name: 'Transcript', value: 'Transcripts are not included in staff reports for privacy.' }
                            )
                            .setTimestamp()
                            .setColor(0xffcc00);

                        const logMessage = await logChannel.send({ embeds: [logEmbed] });

                        const thread = await logMessage.startThread({
                            name: `Report #${ticketNumber} Media`,
                            autoArchiveDuration: 60, // 60 minutes (1 hour) of inactivity before archiving
                            reason: 'Staff report media attachments',
                        });

                        if (hasAttachments && msg.attachments.size > 0) {
                            for (const attachment of msg.attachments.values()) {
                                await thread.send({ files: [attachment] });
                            }
                        }
                    }

                    try {
                        const dmEmbed = new EmbedBuilder()
                            .setTitle('Action Required')
                            .setDescription(`Hello <@${reportedUser.id}>,\n\nYou were recently mentioned in a staff report and you have been flagged. Please contact a manager as soon as possible. You cannot act as staff until cleared.\n\nYour case ID: **${ticketNumber}**`)
                            .setColor(0xff0000)
                            .setTimestamp();

                        await reportedUser.send({ embeds: [dmEmbed] });
                    } catch (err) {
                        console.log(`Could not DM reported user ${reportedUser.tag}.`);
                    }

                } else if (i.customId === 'add_more') {
                    await i.update({ content: '🔁 Escalating to a manager for more help.', embeds: [], components: [] });

                    const escalationEmbed = new EmbedBuilder()
                        .setTitle('🆘 Escalation Requested')
                        .setDescription(`<@${reporter.id}> wants to provide more details. A manager should follow up.`)
                        .setColor(0xff0000)
                        .setTimestamp();

                    await channel.send({ content: `<@&${supportRoleID}>`, embeds: [escalationEmbed] });
                }
            });

            buttonCollector.on('end', collected => {
                if (collected.size === 0) {
                    summaryMsg.edit({ content: '❌ No confirmation received. Please try again.', components: [], embeds: [] });
                }
            });
        });

        collector.on('end', async collected => {
            if (collected.size === 0) {
                try {
                    if (channel && channel.isTextBased() && channel.permissionsFor(channel.guild.members.me).has('SendMessages')) {
                        await channel.send(`<@${reporter.id}> You didn’t respond in time. Please run the command again if you still need help.`);
                    } else {
                        console.log('Timeout message not sent: channel unavailable or missing permissions.');
                    }
                } catch (error) {
                    console.error('Failed to send timeout message:', error);
                }
            }
        });

//database for rule break detection
        function detectRuleViolation(text) {
            const t = text.toLowerCase();
            if (t.includes('kill yourself') || t.includes('kys')) return 'Harassment / Hate Speech';
            if (t.includes('kill myself')) return 'Harassment / Hate Speech';
            if (t.includes('nude') || t.includes('onlyfans') || t.includes('nsfw')) return 'Inappropriate Content';
            if (t.includes('scam') || t.includes('fake')) return 'Scamming / Impersonation';
            return null;
        }
    },

    async onInteractionCreate(interaction) {
        if (!interaction.isButton()) return;

        const { customId, channel } = interaction;

        if (customId === 'close_ticket') {
            const confirmEmbed = new EmbedBuilder()
                .setTitle('Confirm Ticket Close')
                .setDescription('Are you sure you want to close this ticket? This action cannot be undone.')
                .setColor(0xff0000);

            const confirmRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('confirm_close_yes').setLabel('Yes').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('confirm_close_no').setLabel('No').setStyle(ButtonStyle.Secondary)
            );

            await interaction.reply({ embeds: [confirmEmbed], components: [confirmRow], ephemeral: true });

        } else if (customId === 'confirm_close_no') {
            await interaction.update({ content: 'Ticket close cancelled.', embeds: [], components: [] });

        } else if (customId === 'confirm_close_yes') {
            await interaction.update({ content: '📝 Thank you for your time. This ticket will now be closed.', components: [], embeds: [] });

            setTimeout(async () => {
                try {
                    await channel.delete();
                } catch { }
            }, 5000);
        }
    },
};
